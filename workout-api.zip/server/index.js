import bcrypt from "bcryptjs";
import cors from "cors";
import crypto from "node:crypto";
import dotenv from "dotenv";
import express from "express";
import jwt from "jsonwebtoken";
import { query } from "./db.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;
const jwtSecret = process.env.JWT_SECRET || "dev-secret-change-me";
const allowedOrigins = (process.env.FRONTEND_URL || "http://localhost:5173")
  .split(",")
  .map((origin) => origin.trim().replace(/\/$/, ""))
  .filter(Boolean);
const resetTokenTtlMinutes = 30;
const muscleGroups = new Set(["legs", "shoulders", "biceps", "triceps", "back", "chest", "abs"]);

app.use(
  cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.includes(origin.replace(/\/$/, ""))) {
        return callback(null, true);
      }
      return callback(new Error("Origin is not allowed by CORS"));
    },
  }),
);
app.use(express.json());

function tokenFor(user) {
  return jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: "30d" });
}

function hashResetToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

function resetUrlFor(req, token) {
  const baseUrl = process.env.APP_URL || req.get("origin") || `${req.protocol}://${req.get("host")}`;
  const url = new URL(baseUrl);
  url.searchParams.set("resetToken", token);
  return url.toString();
}

function normalizeMuscleGroup(value) {
  if (value === undefined) return undefined;
  const muscleGroup = (value || "").toString().trim().toLowerCase();
  if (!muscleGroup) return null;
  if (!muscleGroups.has(muscleGroup)) throw new Error("Invalid muscle group");
  return muscleGroup;
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "Missing token" });

  try {
    const payload = jwt.verify(token, jwtSecret);
    req.user = { id: payload.sub, email: payload.email };
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

function toNumberRows(rows) {
  return rows.map((row) => ({
    ...row,
    weight: row.weight === undefined ? row.weight : Number(row.weight),
    max_weight: row.max_weight === undefined ? row.max_weight : Number(row.max_weight),
    estimated_1rm: row.estimated_1rm === undefined ? row.estimated_1rm : Number(row.estimated_1rm),
    volume: row.volume === undefined ? row.volume : Number(row.volume),
  }));
}

async function ensureOwnExercise(userId, exerciseId) {
  const result = await query("SELECT id FROM exercises WHERE id = $1 AND user_id = $2", [
    exerciseId,
    userId,
  ]);
  return result.rows[0];
}

async function ensureOwnSession(userId, sessionId) {
  const result = await query(
    "SELECT id, user_id, started_at, ended_at, is_explicit, notes FROM sessions WHERE id = $1 AND user_id = $2",
    [sessionId, userId],
  );
  return result.rows[0];
}

app.get("/api/health", (_req, res) => res.json({ ok: true }));

app.post("/api/auth/register", async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password are required" });

  const passwordHash = await bcrypt.hash(password, 10);
  try {
    const result = await query(
      "INSERT INTO users (name, email, password_hash) VALUES ($1, lower($2), $3) RETURNING id, name, email",
      [name || "", email, passwordHash],
    );
    const user = result.rows[0];
    res.status(201).json({ user, token: tokenFor(user) });
  } catch (error) {
    if (error.code === "23505") return res.status(409).json({ error: "Email already exists" });
    throw error;
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const result = await query("SELECT id, name, email, password_hash FROM users WHERE email = lower($1)", [
    email,
  ]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password || "", user.password_hash))) {
    return res.status(401).json({ error: "Invalid email or password" });
  }
  res.json({ user: { id: user.id, name: user.name, email: user.email }, token: tokenFor(user) });
});

app.post("/api/auth/forgot-password", async (req, res) => {
  const email = (req.body.email || "").trim();
  if (!email) return res.status(400).json({ error: "Email is required" });

  const result = await query("SELECT id, email FROM users WHERE email = lower($1)", [email]);
  const user = result.rows[0];
  let reset_url = null;

  if (user) {
    const token = crypto.randomBytes(32).toString("hex");
    const tokenHash = hashResetToken(token);
    await query(
      `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at)
       VALUES ($1, $2, now() + ($3::text || ' minutes')::interval)`,
      [user.id, tokenHash, resetTokenTtlMinutes],
    );
    reset_url = resetUrlFor(req, token);
    console.log(`Password reset link for ${user.email}: ${reset_url}`);
  }

  res.json({
    message: "If that email exists, a password reset link has been created.",
    ...(reset_url ? { reset_url } : {}),
  });
});

app.post("/api/auth/reset-password", async (req, res) => {
  const token = (req.body.token || "").trim();
  const password = req.body.password || "";
  if (!token || !password) return res.status(400).json({ error: "Token and password are required" });
  if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });

  const tokenHash = hashResetToken(token);
  const tokenResult = await query(
    `SELECT prt.id, prt.user_id, u.name, u.email
     FROM password_reset_tokens prt
     JOIN users u ON u.id = prt.user_id
     WHERE prt.token_hash = $1 AND prt.used_at IS NULL AND prt.expires_at > now()
     LIMIT 1`,
    [tokenHash],
  );
  const resetToken = tokenResult.rows[0];
  if (!resetToken) return res.status(400).json({ error: "Reset link is invalid or expired" });

  const passwordHash = await bcrypt.hash(password, 10);
  await query("UPDATE users SET password_hash = $1 WHERE id = $2", [passwordHash, resetToken.user_id]);
  await query("UPDATE password_reset_tokens SET used_at = now() WHERE id = $1", [resetToken.id]);
  await query(
    "UPDATE password_reset_tokens SET used_at = now() WHERE user_id = $1 AND used_at IS NULL",
    [resetToken.user_id],
  );

  const user = { id: resetToken.user_id, name: resetToken.name, email: resetToken.email };
  res.json({ user, token: tokenFor(user) });
});

app.get("/api/me", requireAuth, async (req, res) => {
  const result = await query("SELECT id, name, email FROM users WHERE id = $1", [req.user.id]);
  res.json({ user: result.rows[0] });
});

app.get("/api/exercises", requireAuth, async (req, res) => {
  const search = `%${(req.query.search || "").toString().trim()}%`;
  const result = await query(
    `SELECT e.id, e.name, e.muscle_group, e.is_favorite, e.created_at,
      MAX(s.created_at) AS last_logged_at,
      (
        SELECT json_build_object('weight', s2.weight, 'reps', s2.reps)
        FROM sets s2
        JOIN sessions se2 ON se2.id = s2.session_id
        WHERE s2.exercise_id = e.id AND se2.user_id = $1
        ORDER BY s2.created_at DESC
        LIMIT 1
      ) AS last_set
     FROM exercises e
     LEFT JOIN sets s ON s.exercise_id = e.id
     LEFT JOIN sessions se ON se.id = s.session_id AND se.user_id = e.user_id
     WHERE e.user_id = $1 AND ($2 = '%%' OR e.name ILIKE $2)
     GROUP BY e.id
     ORDER BY e.is_favorite DESC, last_logged_at DESC NULLS LAST, e.name ASC`,
    [req.user.id, search],
  );
  res.json({ exercises: result.rows });
});

app.post("/api/exercises", requireAuth, async (req, res) => {
  const name = (req.body.name || "").trim();
  if (!name) return res.status(400).json({ error: "Exercise name is required" });
  let muscleGroup;
  try {
    muscleGroup = normalizeMuscleGroup(req.body.muscle_group);
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }

  const result = await query(
    `INSERT INTO exercises (user_id, name, muscle_group, is_favorite)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (user_id, (lower(name))) DO UPDATE
       SET name = EXCLUDED.name,
           muscle_group = COALESCE(EXCLUDED.muscle_group, exercises.muscle_group)
     RETURNING id, name, muscle_group, is_favorite, created_at`,
    [req.user.id, name, muscleGroup ?? null, Boolean(req.body.is_favorite)],
  );
  res.status(201).json({ exercise: result.rows[0] });
});

app.patch("/api/exercises/:id", requireAuth, async (req, res) => {
  let muscleGroup;
  try {
    muscleGroup = normalizeMuscleGroup(req.body.muscle_group);
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }
  const hasMuscleGroup = req.body.muscle_group !== undefined;
  const result = await query(
    `UPDATE exercises
     SET name = COALESCE(NULLIF($3, ''), name),
         is_favorite = COALESCE($4, is_favorite),
         muscle_group = CASE WHEN $5::boolean THEN $6 ELSE muscle_group END
     WHERE id = $1 AND user_id = $2
     RETURNING id, name, muscle_group, is_favorite, created_at`,
    [req.params.id, req.user.id, req.body.name?.trim() || null, req.body.is_favorite, hasMuscleGroup, muscleGroup ?? null],
  );
  if (!result.rows[0]) return res.status(404).json({ error: "Exercise not found" });
  res.json({ exercise: result.rows[0] });
});

app.delete("/api/exercises/:id", requireAuth, async (req, res) => {
  await query("DELETE FROM exercises WHERE id = $1 AND user_id = $2", [req.params.id, req.user.id]);
  res.status(204).end();
});

app.get("/api/exercises/:id/previous-session", requireAuth, async (req, res) => {
  if (!(await ensureOwnExercise(req.user.id, req.params.id))) {
    return res.status(404).json({ error: "Exercise not found" });
  }

  const currentSessionId = req.query.current_session_id || null;
  const session = await query(
    `SELECT se.id, se.started_at
     FROM sets st
     JOIN sessions se ON se.id = st.session_id
     WHERE se.user_id = $1
       AND st.exercise_id = $2
       AND ($3::uuid IS NULL OR se.id <> $3::uuid)
     GROUP BY se.id
     ORDER BY se.started_at DESC
     LIMIT 1`,
    [req.user.id, req.params.id, currentSessionId],
  );

  if (!session.rows[0]) return res.json({ session: null, sets: [] });

  const sets = await query(
    `SELECT st.id, st.session_id, st.exercise_id, e.name AS exercise_name,
            st.weight, st.reps, st.set_order, st.created_at
     FROM sets st
     JOIN sessions se ON se.id = st.session_id
     JOIN exercises e ON e.id = st.exercise_id
     WHERE se.user_id = $1 AND st.session_id = $2 AND st.exercise_id = $3
     ORDER BY st.set_order ASC`,
    [req.user.id, session.rows[0].id, req.params.id],
  );

  res.json({ session: session.rows[0], sets: toNumberRows(sets.rows) });
});

app.get("/api/sessions/active", requireAuth, async (req, res) => {
  const result = await query(
    `SELECT id, user_id, started_at, ended_at, is_explicit, notes
     FROM sessions
     WHERE user_id = $1 AND ended_at IS NULL AND is_explicit = true
     ORDER BY started_at DESC
     LIMIT 1`,
    [req.user.id],
  );
  const session = result.rows[0] || null;
  res.json({ session, sets: session ? await setsForSession(req.user.id, session.id) : [] });
});

app.post("/api/sessions", requireAuth, async (req, res) => {
  const active = await query(
    "SELECT id FROM sessions WHERE user_id = $1 AND ended_at IS NULL AND is_explicit = true LIMIT 1",
    [req.user.id],
  );
  if (active.rows[0]) return res.status(409).json({ error: "Finish the active workout before starting another" });

  const startedAt = req.body.started_at ? new Date(req.body.started_at) : new Date();
  if (Number.isNaN(startedAt.getTime())) return res.status(400).json({ error: "Invalid start date" });

  const result = await query(
    `INSERT INTO sessions (user_id, started_at, notes, is_explicit)
     VALUES ($1, $2, $3, true)
     RETURNING id, user_id, started_at, ended_at, is_explicit, notes`,
    [req.user.id, startedAt.toISOString(), req.body.notes || null],
  );
  res.status(201).json({ session: result.rows[0], sets: [] });
});

app.get("/api/sessions", requireAuth, async (req, res) => {
  const result = await query(
    `SELECT se.id, se.started_at, se.ended_at, se.is_explicit, se.notes, COUNT(st.id)::int AS set_count,
            COALESCE(SUM(st.weight * st.reps), 0)::numeric AS volume
     FROM sessions se
     LEFT JOIN sets st ON st.session_id = se.id
     WHERE se.user_id = $1
     GROUP BY se.id
     ORDER BY se.started_at DESC`,
    [req.user.id],
  );
  res.json({ sessions: toNumberRows(result.rows) });
});

app.get("/api/sessions/:id", requireAuth, async (req, res) => {
  const session = await query("SELECT id, started_at, ended_at, is_explicit, notes FROM sessions WHERE id = $1 AND user_id = $2", [
    req.params.id,
    req.user.id,
  ]);
  if (!session.rows[0]) return res.status(404).json({ error: "Session not found" });
  res.json({ session: session.rows[0], sets: await setsForSession(req.user.id, req.params.id) });
});

app.get("/api/sessions/:id/recap", requireAuth, async (req, res) => {
  const session = await query("SELECT id, started_at, ended_at, is_explicit, notes FROM sessions WHERE id = $1 AND user_id = $2", [
    req.params.id,
    req.user.id,
  ]);
  if (!session.rows[0]) return res.status(404).json({ error: "Session not found" });

  const sets = await setsForSession(req.user.id, req.params.id);
  const achievements = await query(
    `WITH current_exercises AS (
       SELECT st.exercise_id, e.name AS exercise_name,
              MAX(st.weight)::numeric AS max_weight,
              MAX(st.weight * (1 + st.reps / 30.0))::numeric AS estimated_1rm,
              SUM(st.weight * st.reps)::numeric AS volume,
              COUNT(st.id)::int AS set_count
       FROM sets st
       JOIN exercises e ON e.id = st.exercise_id
       WHERE st.session_id = $1
       GROUP BY st.exercise_id, e.name
     ),
     prior AS (
       SELECT st.exercise_id,
              MAX(st.weight)::numeric AS previous_max_weight,
              MAX(st.weight * (1 + st.reps / 30.0))::numeric AS previous_estimated_1rm,
              COUNT(st.id)::int AS previous_set_count
       FROM sets st
       JOIN sessions se ON se.id = st.session_id
       JOIN sessions current_session ON current_session.id = $1
       WHERE se.user_id = $2
         AND se.id <> $1
         AND se.started_at < current_session.started_at
       GROUP BY st.exercise_id
     ),
     prior_volume AS (
       SELECT exercise_id, MAX(volume)::numeric AS previous_max_volume
       FROM (
         SELECT st.exercise_id, se.started_at::date AS workout_date,
                SUM(st.weight * st.reps)::numeric AS volume
         FROM sets st
         JOIN sessions se ON se.id = st.session_id
         JOIN sessions current_session ON current_session.id = $1
         WHERE se.user_id = $2
           AND se.id <> $1
           AND se.started_at < current_session.started_at
         GROUP BY st.exercise_id, se.started_at::date
       ) daily_volume
       GROUP BY exercise_id
     )
     SELECT ce.exercise_id, ce.exercise_name, ce.max_weight, ce.estimated_1rm,
            ce.volume, ce.set_count,
            prior.previous_max_weight, prior.previous_estimated_1rm,
            prior_volume.previous_max_volume,
            COALESCE(prior.previous_set_count, 0)::int AS previous_set_count
     FROM current_exercises ce
     LEFT JOIN prior ON prior.exercise_id = ce.exercise_id
     LEFT JOIN prior_volume ON prior_volume.exercise_id = ce.exercise_id
     ORDER BY ce.exercise_name ASC`,
    [req.params.id, req.user.id],
  );

  res.json({
    session: session.rows[0],
    sets,
    achievements: toNumberRows(achievements.rows),
  });
});

app.patch("/api/sessions/:id", requireAuth, async (req, res) => {
  const startedAt = req.body.started_at === undefined ? undefined : new Date(req.body.started_at);
  const endedAt =
    req.body.ended_at === undefined || req.body.ended_at === null ? req.body.ended_at : new Date(req.body.ended_at);
  if (startedAt !== undefined && Number.isNaN(startedAt.getTime())) {
    return res.status(400).json({ error: "Invalid start date" });
  }
  if (endedAt instanceof Date && Number.isNaN(endedAt.getTime())) {
    return res.status(400).json({ error: "Invalid end date" });
  }

  const result = await query(
    `UPDATE sessions
     SET notes = COALESCE($3, notes),
         started_at = COALESCE($4, started_at),
         ended_at = CASE WHEN $5::boolean THEN $6::timestamptz ELSE ended_at END
     WHERE id = $1 AND user_id = $2
     RETURNING id, started_at, ended_at, is_explicit, notes`,
    [
      req.params.id,
      req.user.id,
      req.body.notes === undefined ? null : req.body.notes || null,
      startedAt === undefined ? null : startedAt.toISOString(),
      req.body.ended_at !== undefined,
      endedAt === null || endedAt === undefined ? null : endedAt.toISOString(),
    ],
  );
  if (!result.rows[0]) return res.status(404).json({ error: "Session not found" });
  res.json({ session: result.rows[0] });
});

app.patch("/api/sessions/:id/end", requireAuth, async (req, res) => {
  const session = await ensureOwnSession(req.user.id, req.params.id);
  if (!session) return res.status(404).json({ error: "Session not found" });
  if (session.ended_at) return res.status(400).json({ error: "Workout is already ended" });

  const endedAt = req.body.ended_at ? new Date(req.body.ended_at) : new Date();
  if (Number.isNaN(endedAt.getTime())) return res.status(400).json({ error: "Invalid end date" });

  const result = await query(
    `UPDATE sessions
     SET ended_at = GREATEST($3::timestamptz, started_at)
     WHERE id = $1 AND user_id = $2
     RETURNING id, started_at, ended_at, is_explicit, notes`,
    [req.params.id, req.user.id, endedAt.toISOString()],
  );
  res.json({ session: result.rows[0] });
});

app.delete("/api/sessions/:id", requireAuth, async (req, res) => {
  await query("DELETE FROM sessions WHERE id = $1 AND user_id = $2", [req.params.id, req.user.id]);
  res.status(204).end();
});

app.post("/api/sets", requireAuth, async (req, res) => {
  const { exercise_id: exerciseId } = req.body;
  const sessionId = req.body.session_id;
  const weight = Number(req.body.weight);
  const reps = Number.parseInt(req.body.reps, 10);
  if (!sessionId || !exerciseId || !Number.isFinite(weight) || !Number.isInteger(reps) || reps < 1) {
    return res.status(400).json({ error: "Workout, exercise, weight, and reps are required" });
  }
  if (!(await ensureOwnExercise(req.user.id, exerciseId))) {
    return res.status(404).json({ error: "Exercise not found" });
  }

  const session = await ensureOwnSession(req.user.id, sessionId);
  if (!session) return res.status(404).json({ error: "Session not found" });
  if (!session.is_explicit) return res.status(400).json({ error: "Start a new workout before logging sets" });
  if (session.ended_at && !req.body.allow_ended) {
    return res.status(400).json({ error: "Cannot log sets to an ended workout" });
  }

  const orderResult = await query(
    "SELECT COALESCE(MAX(set_order), 0) + 1 AS next_order FROM sets WHERE session_id = $1",
    [session.id],
  );
  const result = await query(
    `INSERT INTO sets (session_id, exercise_id, weight, reps, set_order)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, session_id, exercise_id, weight, reps, set_order, created_at`,
    [session.id, exerciseId, weight, reps, Number(orderResult.rows[0].next_order)],
  );
  res.status(201).json({ set: toNumberRows(result.rows)[0] });
});

app.patch("/api/sets/:id", requireAuth, async (req, res) => {
  if (req.body.session_id) {
    const targetSession = await ensureOwnSession(req.user.id, req.body.session_id);
    if (!targetSession) return res.status(404).json({ error: "Target workout not found" });

    const orderResult = await query(
      "SELECT COALESCE(MAX(set_order), 0) + 1 AS next_order FROM sets WHERE session_id = $1",
      [targetSession.id],
    );
    const moved = await query(
      `UPDATE sets st
       SET session_id = $3, set_order = $4
       FROM sessions se
       WHERE st.session_id = se.id AND st.id = $1 AND se.user_id = $2
       RETURNING st.id, st.session_id, st.exercise_id, st.weight, st.reps, st.set_order, st.created_at`,
      [req.params.id, req.user.id, targetSession.id, Number(orderResult.rows[0].next_order)],
    );
    if (!moved.rows[0]) return res.status(404).json({ error: "Set not found" });
    return res.json({ set: toNumberRows(moved.rows)[0] });
  }

  const result = await query(
    `UPDATE sets st
     SET weight = COALESCE($3, st.weight),
         reps = COALESCE($4, st.reps)
     FROM sessions se
     WHERE st.session_id = se.id AND st.id = $1 AND se.user_id = $2
     RETURNING st.id, st.session_id, st.exercise_id, st.weight, st.reps, st.set_order, st.created_at`,
    [req.params.id, req.user.id, req.body.weight ?? null, req.body.reps ?? null],
  );
  if (!result.rows[0]) return res.status(404).json({ error: "Set not found" });
  res.json({ set: toNumberRows(result.rows)[0] });
});

app.delete("/api/sets/:id", requireAuth, async (req, res) => {
  await query(
    `DELETE FROM sets st USING sessions se
     WHERE st.session_id = se.id AND st.id = $1 AND se.user_id = $2`,
    [req.params.id, req.user.id],
  );
  res.status(204).end();
});

app.get("/api/progress/frequency/heatmap", requireAuth, async (req, res) => {
  const result = await query(
    `SELECT started_at::date AS date, COUNT(*)::int AS count
     FROM sessions
     WHERE user_id = $1
     GROUP BY started_at::date
     ORDER BY date ASC`,
    [req.user.id],
  );
  res.json({ days: result.rows });
});

app.get("/api/progress/:exerciseId", requireAuth, async (req, res) => {
  if (!(await ensureOwnExercise(req.user.id, req.params.exerciseId))) {
    return res.status(404).json({ error: "Exercise not found" });
  }

  const series = await query(
    `SELECT se.started_at::date AS date,
            MAX(st.weight)::numeric AS max_weight,
            MAX(st.weight * (1 + st.reps / 30.0))::numeric AS estimated_1rm,
            SUM(st.weight * st.reps)::numeric AS volume
     FROM sets st
     JOIN sessions se ON se.id = st.session_id
     WHERE se.user_id = $1 AND st.exercise_id = $2
     GROUP BY se.started_at::date
     ORDER BY date ASC`,
    [req.user.id, req.params.exerciseId],
  );
  const pr = await query(
    `SELECT MAX(st.weight)::numeric AS max_weight
     FROM sets st
     JOIN sessions se ON se.id = st.session_id
     WHERE se.user_id = $1 AND st.exercise_id = $2`,
    [req.user.id, req.params.exerciseId],
  );
  res.json({ series: toNumberRows(series.rows), pr: toNumberRows(pr.rows)[0] });
});

async function setsForSession(userId, sessionId) {
  const result = await query(
    `SELECT st.id, st.session_id, st.exercise_id, e.name AS exercise_name,
            st.weight, st.reps, st.set_order, st.created_at
     FROM sets st
     JOIN sessions se ON se.id = st.session_id
     JOIN exercises e ON e.id = st.exercise_id
     WHERE se.user_id = $1 AND st.session_id = $2
     ORDER BY st.set_order DESC`,
    [userId, sessionId],
  );
  return toNumberRows(result.rows);
}

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: "Server error" });
});

app.listen(port, () => {
  console.log(`API listening on http://localhost:${port}`);
});
